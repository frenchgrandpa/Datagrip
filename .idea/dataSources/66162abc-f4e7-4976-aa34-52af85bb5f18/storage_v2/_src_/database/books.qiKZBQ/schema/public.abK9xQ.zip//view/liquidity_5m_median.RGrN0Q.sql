create view liquidity_5m_median(token, tag, bps, timestamp, ask_liquidity, bid_liquidity) as
SELECT _materialized_hypertable_76.token,
       _materialized_hypertable_76.tag,
       _materialized_hypertable_76.bps,
       _materialized_hypertable_76."timestamp",
       _materialized_hypertable_76.ask_liquidity,
       _materialized_hypertable_76.bid_liquidity
FROM _timescaledb_internal._materialized_hypertable_76
WHERE _materialized_hypertable_76."timestamp" <
      COALESCE(_timescaledb_internal.to_timestamp(_timescaledb_internal.cagg_watermark(76)),
               '-infinity'::timestamp with time zone)
UNION ALL
SELECT liquidity_logs.token,
       liquidity_logs.tag,
       liquidity_logs.bps,
       time_bucket('00:05:00'::interval, liquidity_logs."timestamp")            AS "timestamp",
       percentile_cont(0.5::double precision)
       WITHIN GROUP (ORDER BY (liquidity_logs.ask_liquidity::double precision)) AS ask_liquidity,
       percentile_cont(0.5::double precision)
       WITHIN GROUP (ORDER BY (liquidity_logs.bid_liquidity::double precision)) AS bid_liquidity
FROM liquidity_logs
WHERE liquidity_logs."timestamp" >=
      COALESCE(_timescaledb_internal.to_timestamp(_timescaledb_internal.cagg_watermark(76)),
               '-infinity'::timestamp with time zone)
GROUP BY liquidity_logs.token, liquidity_logs.tag, liquidity_logs.bps,
         (time_bucket('00:05:00'::interval, liquidity_logs."timestamp"));

alter table liquidity_5m_median
    owner to postgres;

grant select on liquidity_5m_median to grafana;

