create view web_socket_status_5m_aggregate(name, timestamp, time_since_last_message, connected) as
SELECT _materialized_hypertable_79.name,
       _materialized_hypertable_79."timestamp",
       _materialized_hypertable_79.time_since_last_message,
       _materialized_hypertable_79.connected
FROM _timescaledb_internal._materialized_hypertable_79
WHERE _materialized_hypertable_79."timestamp" <
      COALESCE(_timescaledb_internal.to_timestamp(_timescaledb_internal.cagg_watermark(79)),
               '-infinity'::timestamp with time zone)
UNION ALL
SELECT web_socket_status_logs.name,
       time_bucket('00:05:00'::interval, web_socket_status_logs."timestamp")                     AS "timestamp",
       max(web_socket_status_logs."timestamp" -
           web_socket_status_logs.received_last_message_at)                                      AS time_since_last_message,
       bool_and(web_socket_status_logs.connected)                                                AS connected
FROM web_socket_status_logs
WHERE web_socket_status_logs."timestamp" >=
      COALESCE(_timescaledb_internal.to_timestamp(_timescaledb_internal.cagg_watermark(79)),
               '-infinity'::timestamp with time zone)
GROUP BY web_socket_status_logs.name, (time_bucket('00:05:00'::interval, web_socket_status_logs."timestamp"));

alter table web_socket_status_5m_aggregate
    owner to postgres;

grant select on web_socket_status_5m_aggregate to grafana;

